package tn.esprit.account_managment.dto;

public enum TypeBankAccount
{
   currentAccount, savingsAccount
}
