package tn.esprit.account_managment.model;

public enum FeeType {
    TRANSACTION_FEE_currentAccount,
    TRANSACTION_FEE_savingsAccount,
    CURRENCY_CONVERSION_FEE
}
