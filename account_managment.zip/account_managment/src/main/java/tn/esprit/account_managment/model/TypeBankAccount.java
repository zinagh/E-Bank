package tn.esprit.account_managment.model;

public enum TypeBankAccount
{
   currentAccount, savingsAccount
}
